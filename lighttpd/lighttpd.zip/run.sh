export LD_LIBRARY_PATH=$(pwd)/lib
export PATH=$PATH:$(pwd)
lighttpd -f conf/

